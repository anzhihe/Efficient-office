# Interface

> A minimal (less than 30 lines of expanded CSS) old-looking modern theme for Typora

![](preview.png)
![](source.png)

## Fonts

* Futura
* Palatino
* Victor Mono/Courier New
