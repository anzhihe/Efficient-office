## भारतीय आविष्कारें

- Zero
- Ayurveda
- USB *(Universal Serial Bus)*
- Board Games
  - Ashtapada - Chess
  - Mokshapat - Snake and Ladders
- Yoga
- Shampoo
- Wireless Communication
- Buttons
- Cure for leprosy and lithiasis
- Cataract surgery
- Natural fibers
- Plastic Surgery
- Flush Toilets
