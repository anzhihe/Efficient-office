<?php

// select target app
$alfred2bid='com.runningwithcrayons.Alfred-2';
$alfred3bid='com.runningwithcrayons.Alfred-3';
$bid=trim(force_string(`./SelectApp ${alfred3bid} ${alfred2bid}`));

if(strlen($bid)>0) {
	// get the popclip text
	$popclip_text=applescript_safe(trim(force_string(getenv('POPCLIP_TEXT'))));	
	$applescript=escapeshellarg("tell application id \"$bid\" to search \"c $popclip_text\"");
	$applescript2=escapeshellarg("tell application \"System Events\" to key code 36");
	//$result=`echo  $applescript | osascript -`;
	$result=`osascript -e $applescript && osascript -e $applescript2`;
}

function force_string($str) {
	return is_string($str)?$str:'';
}

// escape backslashes and double quotes
function applescript_safe($string) {
	$string=str_replace("\\", "\\\\", $string);
	$string=str_replace("\"", "\\\"", $string);
	return $string;
}

?>
