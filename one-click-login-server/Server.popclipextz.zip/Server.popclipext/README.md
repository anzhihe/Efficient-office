Alfred extensions of PopClip.

### 19 May 2016

Added support for Alfred 3.

### 20 May 2016

Fixed bug where user text was not properly escaped for AppleScript.

### 2019.02.20 by anzhihe

Use alfred login server: Modified Alfred extensions of PopClip https://chegva.com.

